package com.aidata.movieinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieinfoApplication.class, args);
	}

}
